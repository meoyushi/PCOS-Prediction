from setuptools import setup

setup(
    name='Package',
    version='1.0',
    description='A sample Python package',
    author='Aayushi',
    author_email='arthakre30@gmail.com',
    packages=['streamlit'],
)
