# PCOS-Prediction
Working over a dataset found on kaggle, to predict the diagnosis of PCOS
